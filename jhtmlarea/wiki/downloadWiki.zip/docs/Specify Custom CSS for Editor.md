# Specify Custom CSS for Editor
Even though jHtmlArea contains some "default" CSS to use for styling the WYSIWYG editor; it can be overridden to use which ever CSS file necessary to skin the editor to match the web page with which it resides. To do this just set the "{{css}}" option parameter when creating the jHtmlArea editor to URL of the desired CSS file.
{code:javascript}
$('textarea').htmlarea({
    css: '/style//jHtmlArea.Editor.css'
});
{code:javascript}