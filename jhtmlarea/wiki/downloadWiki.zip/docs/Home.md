**Project Description**
A simple, light weight, extensible WYSIWYG HTML Editor built on top of jQuery.

This project also includes Visual Studio JavaScript Intellisense support.

Live Demo: [http://pietschsoft.com/demo/jHtmlArea](http://pietschsoft.com/demo/jHtmlArea)

## Key Advantages of jHtmlArea
* Free, open source ([Microsoft Public License](http://jhtmlarea.codeplex.com/license))
* Simple and Lightweight - 11kb minified - 25.3kb w/ css and images
* Supports all mainstream browsers - IE7{"+"}, Firefox 3{"+"}, Safari 4{"+"}, Chrome
* Built on top of jQuery (requires jQuery 1.3.2 or higher)
* Full Documentation

## View [Documentation](http://jhtmlarea.codeplex.com/documentation) for full usage examples

## Nuget Package
[http://nuget.org/packages/jHtmlArea](http://nuget.org/packages/jHtmlArea)

![Install SQLinq via Nuget](Home_http://download-codeplex.sec.s-msft.com/Download?ProjectName=jhtmlarea&DownloadId=636144|http://nuget.org/packages/jHtmlArea)

![](Home_Screenshot.png)

## Tutorials / Articles
* [jHtmlArea - The all NEW HTML WYSIWYG Editor for jQuery](http://pietschsoft.com/post/2009/07/21/jHtmlArea-The-all-NEW-HTML-WYSIWYG-Editor-for-jQuery.aspx)
* [Adding Custom Toolbar Buttons](http://pietschsoft.com/post/2009/08/18/jHtmlArea-Adding-Custom-Toolbar-Buttons.aspx)

## Basic Usage
{code:javascript}
$(function(){
    $("textarea").htmlarea();
});
{code:javascript}

## Icons
This project also includes icons from the Silk Icon Set by Mark James. You can download the Silk Icon Set here: [http://www.famfamfam.com/lab/icons/silk/](http://www.famfamfam.com/lab/icons/silk/)

## Contributors
This project is maintained by [Chris Pietschmann](http://buildazure.com). He is a Microsoft MVP and a Microsoft Certified Azure Solutions Architect.