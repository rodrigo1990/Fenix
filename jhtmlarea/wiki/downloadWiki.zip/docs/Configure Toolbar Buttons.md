# Configure jHtmlArea Toolbar Buttons

jHtmlArea makes it extremely simple to define custom toolbar button sets. This allows for any combination or subset of toolbar buttons to be displayed; if the default set isn't necessary or desired.

Here's an example that turns a {{<textarea>}} with "{{id='txtCustomHtmlArea}}" into a jHtmlArea Editor and sets specific Toolbar buttons to be displayed:
{code:javascript}
$('#txtCustomHtmlArea'}.htmlarea({
toolbar: [
        "bold", "italic", "underline",
        "|",
        "h1", "h2", "h3", "h4", "h5", "h6",
        "|",
        "link", "unlink"
    ]
});
{code:javascript}
This code tells the editor to only show the 11 butons specified. The items with the pipe "{{|}}" are items that tell the editor to add a separator to give visual grouping to the buttons being displayed.

## Create Toolbar Button Groups
The toolbar buttons can also be visually grouped to allow for related buttons separated from others. To do this, just set the "{{toolbar}}" option to an array of arrays. Each Array within will be displayed as a separate group.

Here's an example that take the above custom toolbar example and separates the related buttons into groups instead of just placing a toolbar separator between them.
{code:javascript}
$('#txtCustomHtmlArea'}.htmlarea({
toolbar: [
        ["bold", "italic", "underline"](_bold_,-_italic_,-_underline_),
        ["h1", "h2", "h3", "h4", "h5", "h6"](_h1_,-_h2_,-_h3_,-_h4_,-_h5_,-_h6_),
        ["link", "unlink"](_link_,-_unlink_)
    ]
});
{code:javascript}

## Available Toolbar Buttons
The below table contains a list of all the "built-in" toolbar buttons that can be used.

|| Name || Description ||
| html | Allows for the user to toggle between WYSIWYG and Raw HTML views within the editor. |
| {{|}} | Created a toolbar separator |
| bold | Surrounds the selected text with {{<b>}} or {{<strong>}} tags (which one depends on the browser used.) |
| italic | Surrounds the selected text with {{<i>}} or {{<em>}} tags (which one depends on the browser used.) |
| underline |  |
| strikethrough | Strikes out the currently selected text with {{<strike>}} tags |
| p | Creates a new paragraph "{{<p>}}" |
| h1 | Surrounds the selected text with a {{<h1>}} tag. |
| h2 | Surrounds the selected text with a {{<h2>}} tag. |
| h3 | Surrounds the selected text with a {{<h3>}} tag. |
| h4 | Surrounds the selected text with a {{<h4>}} tag. |
| h5 | Surrounds the selected text with a {{<h5>}} tag. |
| h6 | Surrounds the selected text with a {{<h6>}} tag. |
| image | Allows for an image to be inserted into the current caret location. |
| link | Adds a hyperlink {{<a>}} to the currently selected text. |
| unlink | Removes the hyperlink from the currently selected text. |
| orderedList | Creates an Ordered List {{<ol>}} |
| unorderedList | Creates an Unorderd List {{<ul>}} |
| superscript | Surrounds the selected text with {{<sup>}} tags. |
| subscript | Surrounds the selected text with {{<sub>}} tags. |
| indent | Indents the selected text. |
| outdent | Outdents the selected text. |
| justifyleft | Left justifies the selected text. |
| justifycenter | Centers the selected text. |
| justifyright | Right justifies the selected text. |
| increasefontsize | Increases the font size of the selected text by one value. |
| decreasefontsize | Decreases the font size of the selected text by one value. |
| forecolor | Allows for the "{{color}}" of the selected text to be set. |
| horizontalrule | Adds a horizontal rule {{<hr>}} tag to the current caret location. |