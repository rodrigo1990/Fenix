# jHtmlArea Editor "Load" Event Callback
jHtmlArea exposes the ability to set a callback function to allow for notification when the editor has finished loading within the page. This can be done by setting the callback function using the "{{loaded}}" option when creating the editor.
{code:javascript}
$('textarea').htmlarea({
    loaded: function () {
        // 'this' is equal to the jHtmlArea object

        // peform some action here,
        // now that the editor has been loaded / created
    }
});
{code:javascript}