# Display the jHtmlArea Editor

## Requires jQuery
jHtmlArea has only one dependency: **jQuery**. Since it is a jQuery plugin, it does require you to include the jQuery library within your page.

## Display an Editor
To use jHtmlArea, all you need to do is place a stander HTML {{<textarea>}} on the page, and execute a single line of JavaScript code (using jQuery) to turn that {<textarea>} into a jHtmlArea editor.

**Step 1: Add a {{<textarea>}} to the page**
{code:html}
<textarea></textarea>
{code:html}

**Step 2: Add jHtmlArea library, css and images to your website folder structure.**

**Step 3: Add a reference to the jHtmlArea CSS file to your page**
{code:html}
<link rel="Stylesheet" type="text/css" href="style/jHtmlArea.css" />
{code:html}

**Step 4: Add a reference to the jHtmlArea library to your page**
{code:html}
<script type="text/javascript" src="scripts/jHtmlArea-0.7.0.js"></script>
{code:html}

**Step 5: Add single line of JavaScript / jQuery code to turn the {{<textarea>}} into a jHtmlArea Editor**
{code:javascript}
$('textarea').htmlarea();
{code:javascript}

## Mixing jHtmlArea and Standard TextAreas on Same Page
jHtmlArea and TextAreas can be mixed within the same page since the line of JavaScript / jQuery code to turn a standard {{<textarea>}} into a jHtmlArea (as shown above) uses a CSS selector.

Here's some example HTML for two TextAreas:
{code:html}
<textarea id='txtPlain'></textarea>
<textarea id='txtEditor'></textarea>
{code:html}

And, here's the matching JavaScript / jQuery code to turn just the {{txtEditor}} TextArea into a jHtmlArea:
{code:javascript}
$('#txtEditor').htmlarea();
{code:javascript}