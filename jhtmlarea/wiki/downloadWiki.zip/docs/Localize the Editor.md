# Localize the jHtmlArea Editor

By default, the text for all jHtmlArea toolbar buttons is in English. If you need to localize the editor to a different language, you can set the text to use for each toolbar button (reference them each by name) using the "{{toolbarText}}" option when creating the editor.

Here's a simple example that localizes the "{{bold}}", "{{italic}}" and "{{underline}}" tooblar buttons to German:
{code:javascript}
$("textarea").htmlarea({
    toolbarText: $.extend({}, jHtmlArea.defaultOptions.toolbarText, {
        "bold": "fett",
        "italic": "kursiv",
        "underline": "unterstreichen"
    })
});
{code:javascript}

A global override / localization of jHtmlArea can be performed by overwriting the "{{jHtmlArea.defaultOptions.toolbarText}}" variable if necessary.